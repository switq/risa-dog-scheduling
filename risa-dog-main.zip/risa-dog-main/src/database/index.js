const knexFile = require('../../knexfile')
const knex = require('knex')(knexFile)

module.exports = knex